//
//  ScoreBoardTableViewCell.swift
//  Quiz Of Knowledge
//
//  Created by Intern on 08/10/2020.
//

import UIKit

class ScoreBoardTableViewCell: UITableViewCell {

    @IBOutlet weak var categoryLBL: UILabel!
    @IBOutlet weak var scoreLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
